const $ = (selector) => document.querySelector(selector);
const url = window.location.origin;
// link de referencia para la pagina de inicio
const reference = window.location.search.split('?ref=')[1].split('&')[0];
console.log(reference)
async function getAccount() {
    try {
        // obteniendo wallet de metamask
        if(!window.ethereum) alert('Please install MetaMask');
        const data = await ethereum.request({ method: 'eth_requestAccounts' });
        return data;
    } catch (error) {
        console.error(error);
    }
}

$("#btnConnect").addEventListener("click", () => {
    getAccount().then(addresses=>{
        //cargando link de referencia de la cuenta en UI
        $("#urlRef").innerHTML = url + `?ref=${addresses[0]}`;
    })
});


$("#copy").addEventListener("click",()=>{
    $("#linkRefBack").value = $("#urlRef").innerHTML;
    $("#linkRefBack").select();
    document.execCommand("copy");
})